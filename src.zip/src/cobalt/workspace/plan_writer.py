"""Workspace plan writer — writes and updates .md plan files with YAML front-matter.

Format
------
Every plan file is a markdown document with a YAML front-matter block:

    ---
    <structured metadata — machine-readable>
    ---

    # Human-readable plan body
    ...

Agents read the full file.  Code reads back the front-matter section.
"""

import logging
import re
from datetime import datetime, timezone
from pathlib import Path

import yaml

from cobalt.core.atomic_write import atomic_write
from cobalt.core.file_system import programme_path
from cobalt.intake.steps import StepResult
from cobalt.models.schemas.investigation_plan_schema import InvestigationPlan
from cobalt.models.schemas.signal_profile_schema import SignalProfile

logger = logging.getLogger(__name__)

# Matches an unchecked step checkbox:  - [ ] `STEP_NAME` ...
_PENDING_RE = re.compile(r"^- \[ \] `([^`]+)`", re.MULTILINE)
# Matches any step checkbox (checked or not) capturing the full line and step name
_CHECKBOX_RE = re.compile(r"^(- \[[ x]\] `([^`]+)`.*)$", re.MULTILINE)


def _now() -> str:
    return datetime.now(tz=timezone.utc).isoformat()


# ---------------------------------------------------------------------------
# Front-matter helpers
# ---------------------------------------------------------------------------

def _parse_frontmatter(text: str) -> tuple[dict, str]:
    """Split YAML front-matter from the markdown body.

    Returns (frontmatter_dict, body_text).  If no front-matter is found,
    returns ({}, full_text).
    """
    if not text.startswith("---"):
        return {}, text
    parts = text.split("---\n", 2)
    if len(parts) < 3:
        return {}, text
    try:
        fm = yaml.safe_load(parts[1]) or {}
    except Exception:
        fm = {}
    # strip the blank line that _compose() adds after the closing ---
    body = parts[2].lstrip("\n")
    return fm, body


def _compose(frontmatter: dict, body: str) -> str:
    """Produce the final file content: front-matter block then markdown body."""
    fm_yaml = yaml.dump(frontmatter, default_flow_style=False, allow_unicode=True)
    return f"---\n{fm_yaml}---\n\n{body}"


# ---------------------------------------------------------------------------
# Step description catalogue
# ---------------------------------------------------------------------------

_STEP_DESC: dict[str, str] = {
    "WEB_RESEARCH_FAST":     "One Brave search query — confirm business existence",
    "WEB_RESEARCH_STANDARD": "Standard web research with country context",
    "WEB_RESEARCH_DEEP":     "Deep research — two queries plus entity structuring",
    "FRAUD_CHECK_BASIC":     "Check for shell company patterns and invoice anomalies",
    "FRAUD_CHECK_DEEP":      "Full fraud analysis including HR overlap",
    "FRAUD_CHECK_ASYNC":     "Background fraud check queued for known vendor",
    "SANCTIONS_CHECK":       "OFAC / EU / UN sanctions screening",
    "HR_OVERLAP_CHECK":      "Employee cross-reference to detect insider risk",
    "MERGE_CANONICAL":       "Auto-merge confirmed duplicate into canonical record",
    "CONFIRM_REBRAND":       "Verify rebranding event and update vendor record",
    "CONFIRM_ALIAS":         "Confirm alias relationship with known entity",
    "ROUTE_TO_HUMAN":        "Ambiguous case — escalate to human review queue",
    "LEGAL_GATE":            "Sanctioned-country vendor — route to compliance team",
    "DOCUMENT_EXTRACTION":   "Extract commercial terms from linked documents",
    "TRANSLITERATION":       "Transliterate non-Latin script for search",
    "MULTILINGUAL_SEARCH":   "Run multilingual web research",
}


def _step_desc(step: str) -> str:
    return _STEP_DESC.get(step, step.replace("_", " ").title())


# ---------------------------------------------------------------------------
# write_programme_plan
# ---------------------------------------------------------------------------

def write_programme_plan(programme_id: str, plan_context: dict) -> Path:
    """Write programme_plan.md with YAML front-matter and a readable markdown body.

    plan_context may contain:
      research_tier, document_extraction_enabled, strategy_prose,
      source_summary, expected_distribution, planned_at — and any other keys
      (all non-prose keys land in the front-matter).
    """
    path = programme_path(programme_id) / "programme_run" / "programme_plan.md"
    created = _now()

    # Front-matter: structured metadata
    frontmatter: dict = {"programme_id": programme_id, "created_at": created}
    for k, v in plan_context.items():
        if k not in ("strategy_prose", "source_summary"):
            frontmatter[k] = v

    # Human-readable body
    strategy_prose = plan_context.get("strategy_prose", "Standard intake run.")
    source = plan_context.get("source_summary", {})
    vendor_count = source.get("vendor_list_count", source.get("candidates_total", "—"))
    doc_count    = source.get("doc_count", 0)
    research_tier = plan_context.get("research_tier", "STANDARD")

    body = f"""# Programme Plan — {programme_id}
_Created: {created}_

## Source
- Vendor list entries: {vendor_count}
- Documents: {doc_count}
- Research tier: {research_tier}

## Strategy

{strategy_prose}

## Steps

- [ ] `source_intake` — Parse and deduplicate vendor list
- [ ] `candidate_screening` — Clean, normalize, classify entity types
- [ ] `build_batch_context` — Load Brain knowledge base, run ERP and AP scans
- [ ] `entity_resolution` — Match vendors to known entities, route unknowns
- [ ] `per_candidate_investigation` — Investigate INVESTIGATE-routed vendors
- [ ] `write_programme_report` — Write vendor_register, deduplication_report, run_log

## Execution Log

"""
    atomic_write(path, _compose(frontmatter, body), programme_id=programme_id)
    return path


# ---------------------------------------------------------------------------
# write_investigation_plan
# ---------------------------------------------------------------------------

def write_investigation_plan(
    programme_id: str,
    candidate_key: str,
    profile: SignalProfile,
    plan: InvestigationPlan,
    why_prose: str = "",   # kept for backward compat; plan.focus is preferred
) -> Path:
    """Write IP-{key}-{n}.md with YAML front-matter and a readable markdown body.

    Returns the path to the written file.
    """
    intake_plans_dir = (
        programme_path(programme_id) / "programme_run" / "intake_plans"
    )
    existing = list(intake_plans_dir.glob(f"IP-{candidate_key}-*.md")) \
        if intake_plans_dir.exists() else []
    n = len(existing) + 1
    plan_id = f"IP-{candidate_key}-{n:03d}"
    path = intake_plans_dir / f"{plan_id}.md"

    depth_val = plan.depth.value if hasattr(plan.depth, "value") else str(plan.depth)
    fraud_val = plan.fraud_risk.value if hasattr(plan.fraud_risk, "value") else str(plan.fraud_risk)
    etype_val = profile.entity_type.value if hasattr(profile.entity_type, "value") else str(profile.entity_type)
    spend_val = str(profile.erp_signal.spend) if profile.erp_signal.spend is not None else None
    created   = _now()

    frontmatter = {
        "intake_plan_id": plan_id,
        "programme_id":   programme_id,
        "candidate_raw":  profile.raw,
        "candidate_key":  candidate_key,
        "written_at":     created,
        "signals": {
            "brain_hit": {
                "matched":      profile.brain_hit.matched,
                "confidence":   profile.brain_hit.confidence,
                "canonical":    profile.brain_hit.canonical,
                "match_type":   profile.brain_hit.match_type,
                "rebrand_match": profile.brain_hit.rebrand_match,
                "alias_match":  profile.brain_hit.alias_match,
            },
            "dedup_result": {
                "status":    profile.dedup_result.status,
                "match_key": profile.dedup_result.match_key,
                "similarity": profile.dedup_result.similarity,
            },
            "entity_type": etype_val,
            "erp_spend":   spend_val,
            "linked_docs": profile.linked_doc_ids,
        },
        "plan": {
            "depth":              depth_val,
            "steps":              plan.steps,
            "reason":             plan.reason,
            "require_human_gate": plan.require_human_gate,
            "require_legal_gate": plan.require_legal_gate,
            "fraud_risk":         fraud_val,
        },
        "execution": {
            "started_at":   None,
            "step_results": {},
        },
        "outcome": {
            "status":         "PENDING",
            "vendor_id":      None,
            "workspace_path": None,
        },
    }

    # Step checkboxes — include per-step rationale when available
    step_rationale: dict = getattr(plan, "step_rationale", {})
    focus: str = getattr(plan, "focus", "")

    if plan.steps:
        step_lines_list = []
        for s in plan.steps:
            line = f"- [ ] `{s}` — {_step_desc(s)}"
            rationale = step_rationale.get(s, "")
            if rationale:
                line += f"\n  > _{rationale}_"
            step_lines_list.append(line)
        step_lines = "\n".join(step_lines_list)

        log_rows = "\n".join(f"| `{s}` | PENDING | — |" for s in plan.steps)
        log_table = (
            f"| Step | Status | Summary |\n"
            f"|------|--------|---------|\n"
            f"{log_rows}"
        )
    else:
        step_lines = "_No steps required for this vendor._"
        log_table  = "_No steps to execute._"

    brain_str = (
        f"{profile.brain_hit.canonical} "
        f"({profile.brain_hit.match_type}, {profile.brain_hit.confidence:.0%})"
        if profile.brain_hit.matched else "None"
    )
    erp_str     = str(profile.erp_signal.spend) if profile.erp_signal.spend is not None else "—"
    country_str = profile.country_hint or "—"
    # why_prose (explicit arg) takes priority; fall back to plan.reason
    why_text = why_prose or plan.reason or "Standard investigation."

    focus_section = (
        f"## Investigation Focus\n\n{focus}\n" if focus
        else f"## Investigation Focus\n\n_{plan.reason}_\n"
    )

    body = f"""# Investigation Plan — {profile.raw}
_Plan ID: {plan_id}_ | _Programme: {programme_id}_ | _Written: {created}_

## Entity Profile

| Field | Value |
|-------|-------|
| Raw input | `{profile.raw}` |
| Normalized | `{profile.normalized}` |
| Comparison key | `{profile.comparison_key}` |
| Entity type | {etype_val} |
| Country hint | {country_str} |
| Brain hit | {brain_str} |
| ERP spend | {erp_str} |
| Linked documents | {len(profile.linked_doc_ids)} |

{focus_section}
## Why This Plan

{why_text}

## Steps

{step_lines}

## Execution Log

{log_table}

## Outcome

**Status:** PENDING
**Vendor ID:** —
**Workspace:** —
"""
    atomic_write(path, _compose(frontmatter, body), programme_id=programme_id)
    logger.info("plan_writer: investigation plan → %s  steps=%s", path.name, plan.steps)
    return path


# ---------------------------------------------------------------------------
# update_plan_step
# ---------------------------------------------------------------------------

def update_plan_step(plan_path: Path, step: str, result: StepResult) -> None:
    """Mark a step done in the front-matter, checkbox, and execution log table."""
    if not plan_path.exists():
        return
    try:
        text = plan_path.read_text(encoding="utf-8")
        fm, body = _parse_frontmatter(text)

        # Update front-matter execution block
        execution = fm.setdefault("execution", {})
        if not execution.get("started_at"):
            execution["started_at"] = _now()
        execution.setdefault("step_results", {})[step] = {
            "success":    result.success,
            "early_exit": result.early_exit,
            "data":       result.data,
            "note":       result.note,
        }

        # Tick checkbox in body
        def _tick(m: re.Match) -> str:
            if m.group(2) == step:
                rest = m.group(0)[len(f"- [ ] `{step}`"):]
                return f"- [x] `{step}`{rest}"
            return m.group(0)
        body = _CHECKBOX_RE.sub(_tick, body)

        # Update execution log table row
        status_str = "DONE" if result.success else "FAILED"
        summary    = (result.note or "").strip() or ("ok" if result.success else "failed")
        _repl = f"| `{step}` | {status_str} | {summary} |"
        body = re.sub(
            rf"^\| `{re.escape(step)}` \| PENDING \| — \|$",
            lambda _: _repl,
            body,
            flags=re.MULTILINE,
        )

        atomic_write(plan_path, _compose(fm, body))
        status_tag = "DONE" if result.success else "FAILED"
        logger.info("plan_writer: step %s → %s  (%s)", step, status_tag, plan_path.name)
    except Exception as exc:
        logger.warning("update_plan_step failed for %s: %s", plan_path, exc)


# ---------------------------------------------------------------------------
# finalise_plan
# ---------------------------------------------------------------------------

def finalise_plan(
    plan_path: Path,
    status: str,
    vendor_id: str | None = None,
    workspace_path: str | None = None,
) -> None:
    """Write the final outcome into the front-matter and the Outcome section."""
    if not plan_path.exists():
        return
    try:
        text = plan_path.read_text(encoding="utf-8")
        fm, body = _parse_frontmatter(text)

        # Update front-matter
        outcome = fm.setdefault("outcome", {})
        outcome["status"]         = status
        outcome["vendor_id"]      = vendor_id
        outcome["workspace_path"] = workspace_path
        execution = fm.setdefault("execution", {})
        if not execution.get("started_at"):
            execution["started_at"] = _now()

        # Update Outcome section in body
        vid_str = vendor_id or "—"
        ws_str  = workspace_path or "—"
        _repl = f"**Status:** {status}\n**Vendor ID:** {vid_str}\n**Workspace:** {ws_str}"
        body = re.sub(
            r"\*\*Status:\*\* [^\n]+\n\*\*Vendor ID:\*\* [^\n]+\n\*\*Workspace:\*\* [^\n]+",
            lambda _: _repl,
            body,
        )

        atomic_write(plan_path, _compose(fm, body))
        logger.info("plan_writer: finalised %s → %s  vendor_id=%s", plan_path.name, status, vendor_id)
    except Exception as exc:
        logger.warning("finalise_plan failed for %s: %s", plan_path, exc)


# ---------------------------------------------------------------------------
# read_next_pending_step
# ---------------------------------------------------------------------------

def read_next_pending_step(plan_path: Path) -> str | None:
    """Return the first pending step name from a plan file's checkbox list."""
    if not plan_path.exists():
        return None
    try:
        text = plan_path.read_text(encoding="utf-8")
        m = _PENDING_RE.search(text)
        return m.group(1) if m else None
    except Exception:
        return None
