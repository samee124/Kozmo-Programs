"""Workspace builder — creates all initial files for a confirmed vendor."""

import logging
import re
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path

import yaml

from cobalt.core.atomic_write import append_md, atomic_write
from cobalt.core.file_system import init_vendor_workspace, vendor_path
from cobalt.models.schemas.intake_result_schema import IntakeResult, IntakeStatus
from cobalt.models.schemas.signal_profile_schema import ErpSignal

logger = logging.getLogger(__name__)

_LEGAL_SUFFIX_RE = re.compile(
    r",?\s*(Corporation|Corp\.?|Incorporated|Inc\.?|Limited|Ltd\.?|LLC|LLP|GmbH|Co\.?)$",
    re.IGNORECASE,
)


@dataclass
class WorkspaceBuildResult:
    vendor_id: str
    workspace_path: Path
    files_written: list[str]
    success: bool
    error: str | None


def _now() -> str:
    return datetime.now(tz=timezone.utc).isoformat()


def _make_slug(name: str) -> str:
    """Convert a company name to a lowercase underscore slug, stripping legal suffixes."""
    name = _LEGAL_SUFFIX_RE.sub("", name).strip()
    name = re.sub(r"[^\w\s]", "", name).lower().strip()
    return re.sub(r"\s+", "_", name)


def _pcs_band(pcs: int) -> str:
    if pcs >= 75:
        return "EXECUTION_READY"
    if pcs >= 50:
        return "GUIDED"
    if pcs >= 30:
        return "EXPLORATORY"
    return "INSUFFICIENT"


def _compute_pcs(erp_signal: ErpSignal | None, extracted_terms: dict | None) -> int:
    pcs = 0
    if erp_signal and erp_signal.spend is not None:
        pcs += 12
    if extracted_terms:
        if extracted_terms.get("renewal_date") is not None:
            pcs += 15
        if extracted_terms.get("auto_renewal") is not None:
            pcs += 10
        if extracted_terms.get("contract_value") is not None:
            pcs += 8
        if extracted_terms.get("price_escalation") is not None:
            pcs += 5
        if extracted_terms.get("baa_present") is True:
            pcs += 5
    return pcs


def _legal_field(key: str, extracted_terms: dict | None) -> dict:
    val = extracted_terms.get(key) if extracted_terms else None
    if val is not None:
        return {"value": val, "confidence": "OBSERVED", "source": "CONTRACT_DOC"}
    return {"value": None, "confidence": "INSUF", "source": None}


def build_workspace(
    result: IntakeResult,
    programme_id: str,
    extracted_terms: dict | None = None,
    erp_signal: ErpSignal | None = None,
) -> WorkspaceBuildResult:
    """Create the single vendor *.md file for a confirmed vendor. Raises ValueError if not CONFIRMED."""
    if result.status != IntakeStatus.CONFIRMED:
        raise ValueError(
            f"build_workspace requires CONFIRMED status, got {result.status!r}"
        )

    vendor_id = result.vendor_id
    canonical_name = result.canonical_name or result.raw_input
    slug = _make_slug(canonical_name)
    root = vendor_path(programme_id, vendor_id)
    files_written: list[str] = []

    logger.info("Building workspace for %r  vendor_id=%s", result.raw_input[:40], vendor_id)
    try:
        init_vendor_workspace(programme_id, vendor_id)

        pcs_score = _compute_pcs(erp_signal, extracted_terms)

        if erp_signal and erp_signal.spend is not None:
            annual_spend = {"value": str(erp_signal.spend), "confidence": "OBSERVED", "source": "ERP"}
            spend_status = "OBSERVED"
        else:
            annual_spend = {"value": None, "confidence": "INSUF", "source": None}
            spend_status = "INFERRED"
        currency = getattr(erp_signal, "currency", None)

        if result.erp_category:
            category = {"value": result.erp_category, "confidence": "OBSERVED", "source": "ERP"}
        else:
            category = {"value": None, "confidence": "INSUF", "source": None}

        documents = []
        if extracted_terms and result.linked_doc_ids:
            for doc_id in result.linked_doc_ids:
                documents.append({
                    "doc_id":   doc_id,
                    "doc_type": extracted_terms.get("doc_type"),
                    "type":     "CONTRACT_DOCUMENT",
                    "status":   "OBSERVED",
                })

        fm: dict = {
            "vendor_id":      vendor_id,
            "canonical_name": canonical_name,
            "slug":           slug,
            "status":         "INTAKE_COMPLETED",
            "intake": {
                "input_name":        result.raw_input,
                "resolution_method": result.resolution_method,
                "data_class":        result.data_class,
                "confidence":        result.confidence,
            },
            "identity": {
                "hq_country": {
                    "value":      result.country_code,
                    "confidence": "OBSERVED" if result.country_code else "INSUF",
                    "source":     "ERP" if result.country_code else None,
                },
            },
            "financial": {
                "spend_status": spend_status,
                "annual_spend": annual_spend,
                "currency":     currency,
            },
            "legal": {
                "renewal_date":    _legal_field("renewal_date",    extracted_terms),
                "auto_renewal":    _legal_field("auto_renewal",    extracted_terms),
                "contract_value":  _legal_field("contract_value",  extracted_terms),
                "price_escalation": _legal_field("price_escalation", extracted_terms),
            },
            "pcs": {
                "score": pcs_score,
                "band":  _pcs_band(pcs_score),
            },
            "classification": {
                "category": category,
            },
            "commercial": {
                "documents": documents,
            },
            "change_log": [{
                "event":     "INTAKE_COMPLETED",
                "timestamp": _now(),
                "pcs_score": pcs_score,
            }],
        }

        file_path = root / f"{slug}.md"
        atomic_write(file_path, fm, vendor_id=vendor_id, programme_id=programme_id)
        files_written.append(str(file_path))

        logger.info("  Workspace ready — single file written for %s", vendor_id)
        return WorkspaceBuildResult(
            vendor_id=vendor_id,
            workspace_path=root,
            files_written=files_written,
            success=True,
            error=None,
        )

    except Exception as exc:
        logger.error("build_workspace failed for vendor %r: %s", vendor_id, exc)
        return WorkspaceBuildResult(
            vendor_id=vendor_id,
            workspace_path=root,
            files_written=files_written,
            success=False,
            error=str(exc),
        )


def write_vendor_profile(
    profile: "VendorProfile",  # type: ignore[name-defined]
    programme_id: str,
    vendor_id: str,
    workspace_root: Path,
) -> Path:
    """Write enriched vendor profile atomically to the vendor directory.

    Uses the same single-file location as build_workspace.
    """
    slug = _make_slug(profile.canonical_name) or vendor_id
    vendor_dir = workspace_root / programme_id / vendor_id
    vendor_dir.mkdir(parents=True, exist_ok=True)
    path = vendor_dir / f"{slug}.md"

    pcs_before = profile.enrichment_metadata.get("pcs_before")
    pcs_after  = profile.enrichment_metadata.get("pcs_after")

    fm: dict = {
        "vendor_id":          profile.vendor_id,
        "canonical_name":     profile.canonical_name,
        "slug":               slug,
        "status":             profile.profile_status,
        "overall_confidence": profile.overall_confidence,
        "enriched_at":        profile.enriched_at,
        "identity":           profile.identity,
        "classification":     profile.classification,
        "size":               profile.size,
        "organisation":       profile.organisation,
        "products_and_services": profile.products_and_services,
        "competitors":        profile.competitors,
        "certifications":     profile.certifications,
        "customer_segments":  profile.customer_segments,
        "reputation_signals": profile.reputation_signals,
        "key_people":         profile.key_people,
        "lifecycle_signals":  [sig.to_dict() for sig in profile.lifecycle_signals],
        "gaps":               profile.gaps,
        "flags":              profile.flags,
        "enrichment_metadata": profile.enrichment_metadata,
        "change_log": [{
            "event":      "ENRICHMENT_COMPLETED",
            "enriched_at": profile.enriched_at,
            "pcs_before": pcs_before,
            "pcs_after":  pcs_after,
        }],
    }

    yaml_str = yaml.dump(fm, default_flow_style=False, allow_unicode=True)
    description = (profile.identity.get("description", {}) or {})
    desc_text = (description.get("value") if isinstance(description, dict) else description) or "_No description available._"
    body = f"# {profile.canonical_name}\n\n{desc_text}\n\n**Status:** {profile.profile_status}\n"
    content = f"---\n{yaml_str}---\n\n{body}"

    atomic_write(path, content, vendor_id=vendor_id, programme_id=programme_id)
    return path


def append_enrichment_ledger_entry(
    programme_id: str,
    vendor_id: str,
    workspace_root: Path,
    profile_status: str,
    overall_confidence: str,
    depth_tier: str,
    sources_used: list[str],
    flags: list[str],
    pcs_before: float,
    pcs_after: float,
    now: str,
) -> None:
    """Append an enrichment ledger entry. Kept for backwards compatibility."""
    from cobalt.core.file_system import _find_vendor_file, read_md
    file_path = _find_vendor_file(programme_id, vendor_id, workspace_root)
    if file_path is None:
        logger.warning("No vendor file found for ledger entry: %s", vendor_id)
        return
    existing = read_md(file_path) or {}
    change_log = list(existing.get("change_log") or [])
    change_log.append({
        "event":              "ENRICHMENT_COMPLETED",
        "enriched_at":        now,
        "depth_tier":         depth_tier,
        "profile_status":     profile_status,
        "overall_confidence": overall_confidence,
        "sources_used":       sources_used,
        "flags":              flags,
        "pcs_before":         round(pcs_before, 4),
        "pcs_after":          round(pcs_after, 4),
    })
    existing["change_log"] = change_log
    atomic_write(file_path, existing, vendor_id=vendor_id, programme_id=programme_id)
